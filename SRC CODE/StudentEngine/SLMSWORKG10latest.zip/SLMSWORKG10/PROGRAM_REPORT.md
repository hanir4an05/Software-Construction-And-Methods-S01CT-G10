# Student and Course Management System Report

Date: March 24, 2026
Project Path: `c:\Users\Me\Desktop\SLMSWORKG10`

## 1. Program Overview
This Java console application provides two modules:
- Course Management
- Student Management

Users can add, search, edit, delete, and display records through menu-driven input.

## 2. Current Architecture
The intended (refactored) package-based structure is:
- `model/`
  - `Course.java`
  - `Student.java`
- `engine/`
  - `CourseEngine.java`
  - `StudentEngine.java`
- `ui/`
  - `Main.java`
  - `DefineStudent.java`

There are also legacy Java files in the project root:
- `Course.java`
- `CourseEngine.java`
- `Main.java`
- `StudentEngine.java`

These root files are older/default-package copies and can conflict with the packaged version if the wrong compile command is used.

## 3. Functional Assessment
### Course Module
Implemented features:
- Add course
- Search by course code
- Edit course fields
- Delete with confirmation
- Display all courses

Status: Working under packaged run path.

### Student Module
Implemented features:
- Add student
- Search by student ID
- Edit student fields
- Delete with confirmation
- Display all students
- Duplicate student ID prevention

Status: Working under packaged run path.

## 4. Build and Runtime Verification
### Successful path (recommended)
Command:
- `javac model\*.java engine\*.java ui\*.java`
- `java ui.Main`

Result:
- Compiles successfully
- Runs successfully
- Main menu displays and exits correctly

### Failing path (legacy/default package)
Command:
- `javac *.java`

Result:
- Fails with unresolved symbols (`Student`, `DefineStudent`, etc.)
- Cause: root-level legacy files are incomplete and not aligned with package-based design

## 5. Hiccups / Risks
- Root-level legacy `.java` files can confuse future builds.
- Data storage uses fixed-size arrays (capacity limit set by constructor).
- No persistence layer (data resets every run).
- Input validation is basic (no strict email format or ID format checks).
- No automated tests currently included.

## 6. Overall Quality Verdict
The program is in a good working state when using the package-based entrypoint (`ui.Main`).

It is not fully foolproof for other users yet because duplicate legacy files in the root can trigger compile errors if they use `javac *.java`.

## 7. Recommended Next Steps
Priority 1:
- Remove or archive root-level legacy Java files.
- Keep only package-structured files.

Priority 2:
- Add duplicate course-code validation in `engine/CourseEngine.java`.
- Add stronger input validation (ID format, email format, empty fields).

Priority 3:
- Replace arrays with `ArrayList` for flexible capacity.
- Add file/database persistence.
- Add unit tests for core engine methods.
